#include<iostream>
#include "executor.h"
using namespace std;

void execute(vector<Instruction>& instructions,RegisterFile& rf){
    for(int i=0;i<instructions.size();i++){
        Instruction inst=instructions[i];

        if(inst.opcode=="addi"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int value=rf.getReg(sourcereg)+imm;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="addiu"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            uint32_t value=rf.getReg(sourcereg)+imm;
            rf.setReg(destreg,int32_t(value));
        }
        else if(inst.opcode=="add"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=rf.getReg(sourcereg1)+rf.getReg(sourcereg2);
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="sub"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=(rf.getReg(sourcereg1))-(rf.getReg(sourcereg2));
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="and"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=(rf.getReg(sourcereg1))&(rf.getReg(sourcereg2));
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="or"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=(rf.getReg(sourcereg1))|(rf.getReg(sourcereg2));
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="nor"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=~((rf.getReg(sourcereg1))|(rf.getReg(sourcereg2)));
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="xor"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];

            int value=(rf.getReg(sourcereg1))^(rf.getReg(sourcereg2));
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="slt"){
            string destreg=inst.operands[0];
            string sourcereg1=inst.operands[1];
            string sourcereg2=inst.operands[2];
            int value;

            int v1=rf.getReg(sourcereg1);
            int v2=rf.getReg(sourcereg2);
            if(v1<v2){
                value=1;
            }
            else value=0;
            
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="andi"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int value=(rf.getReg(sourcereg))&(imm);
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="ori"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int value=(rf.getReg(sourcereg))|(imm);
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="xori"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int value=(rf.getReg(sourcereg))^(imm);
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="slti"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int value;
            int v=rf.getReg(sourcereg);
            if(v<imm){
                value=1;
            }
            else value=0;
            rf.setReg(destreg,value);
        }

        else if(inst.opcode=="sll"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int v=rf.getReg(sourcereg);

            int value=v<<imm;
            rf.setReg(destreg,value);
        }

        else if(inst.opcode=="srl"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            unsigned int v=rf.getReg(sourcereg);

            int value=v>>imm;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="sra"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            string immediate=inst.operands[2];

            int imm = stoi(immediate, nullptr, 0);
            int32_t v=rf.getReg(sourcereg);

            int value=v>>imm;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="mult"){
            string sourcereg1=inst.operands[0];
            string sourcereg2=inst.operands[1];

            int64_t result=(int64_t)rf.getReg(sourcereg1)*rf.getReg(sourcereg2);

            rf.HI=result>>32;
            rf.LO = result & 0xFFFFFFFF;
        }
        else if(inst.opcode=="div"){
            string sourcereg1=inst.operands[0];
            string sourcereg2=inst.operands[1];

            int v1=rf.getReg(sourcereg1);
            int v2=rf.getReg(sourcereg2);

            if(v2==0){
                cout<<"ZeroError: division by zero"<<endl;
                return ;
            }
            rf.LO=v1/v2;
            rf.HI=v1%v2;

        }
        else if(inst.opcode=="lui"){
            string destreg=inst.operands[0];
            string immediate=inst.operands[1];

            int imm = stoi(immediate, nullptr, 0);

            int value=imm<<16;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="mflo"){
            string destreg=inst.operands[0];
            int value=rf.LO;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="mfhi"){
            string destreg=inst.operands[0];
            int value=rf.HI;
            rf.setReg(destreg,value);
        }
        else if(inst.opcode=="mtlo"){
            string sourcereg=inst.operands[0];
            int value=rf.getReg(sourcereg);
            rf.LO=value;
        }
        else if(inst.opcode=="mthi"){
            string sourcereg=inst.operands[0];
            int value=rf.getReg(sourcereg);
            rf.HI=value;
        }
        else if(inst.opcode=="move"){
            string destreg=inst.operands[0];
            string sourcereg=inst.operands[1];
            rf.setReg(destreg,rf.getReg(sourcereg));
        }
        else if(inst.opcode == "nop") {
            continue;
        }
        else{
            cout << "Unknown instruction: " << inst.opcode << endl;
        }


    }
}