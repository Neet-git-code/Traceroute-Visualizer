# MIPS Simulator

A simple MIPS assembly simulator written in C++ that reads a `.asm` file, executes the instructions, and displays the final state of all 32 registers along with the HI and LO special registers.

---

## Project Structure

```
mips_simulator/
├── main.cpp            → Entry point, ties all components together
├── parser.h            → Instruction struct and parser function declarations
├── parser.cpp          → Parses .asm file into a list of instructions
├── registers.h         → RegisterFile struct declaration and initialization
├── registers.cpp       → getReg and setReg function implementations
├── executor.h          → Execute function declaration
├── executor.cpp        → Executes each instruction and updates registers
├── Makefile            → Build configuration
└── test.asm            → Sample test file
```

---

## How to Compile

Make sure you have `g++` installed with C++17 support. Then run:

```bash
make
```

To clean the build:

```bash
make clean
```

---

## How to Run

```bash
./mips_sim <filename.asm>
```

Example:

```bash
./mips_sim test.asm
```

---

## Supported Instructions

### R-Type Instructions
| Instruction | Operation |
|---|---|
| `add rd, rs, rt` | `rd = rs + rt` |
| `sub rd, rs, rt` | `rd = rs - rt` |
| `and rd, rs, rt` | `rd = rs & rt` |
| `or rd, rs, rt` | `rd = rs \| rt` |
| `nor rd, rs, rt` | `rd = ~(rs \| rt)` |
| `xor rd, rs, rt` | `rd = rs ^ rt` |
| `slt rd, rs, rt` | `rd = (rs < rt) ? 1 : 0` |
| `sll rd, rt, shamt` | `rd = rt << shamt` |
| `srl rd, rt, shamt` | `rd = rt >> shamt` (logical) |
| `sra rd, rt, shamt` | `rd = rt >> shamt` (arithmetic) |
| `mult rs, rt` | `HI:LO = rs * rt` |
| `div rs, rt` | `LO = rs / rt, HI = rs % rt` |
| `move $t0, $t1` | `$t0 = $t1` |
| `mtlo rs` | `LO = rs` |
| `mthi rs` | `HI = rs` |


### I-Type Instructions
| Instruction | Operation |
|---|---|
| `addi rt, rs, imm` | `rt = rs + imm` |
| `addiu rt, rs, imm` | `rt = rs + imm` (unsigned) |
| `andi rt, rs, imm` | `rt = rs & imm` |
| `ori rt, rs, imm` | `rt = rs \| imm` |
| `xori rt, rs, imm` | `rt = rs ^ imm` |
| `slti rt, rs, imm` | `rt = (rs < imm) ? 1 : 0` |
| `lui rt, imm` | `rt = imm << 16` |


---

## Sample Test File

```asm
# Sample MIPS program
addi $t0, $zero, 10
addi $t1, $zero, 20
add  $t2, $t0, $t1
sub  $t3, $t1, $t0
and  $t4, $t0, $t1
or   $t5, $t0, $t1
sll  $t6, $t0, 2
srl  $t7, $t1, 1
slt  $s0, $t0, $t1
mult $t0, $t1
div  $t1, $t0
addi $s1, $zero, -5
slti $s2, $s1, 0
```

## Expected Output

```
$zero=0
$at=0
$v0=0
$v1=0
$a0=0
$a1=0
$a2=0
$a3=0
$t0=10
$t1=20
$t2=30
$t3=10
$t4=0
$t5=30
$t6=40
$t7=10
$s0=1
$s1=-5
$s2=1
...
HI=0
LO=2
```

---

## Limitations

- Does not support conditional or unconditional jump instructions (`j`, `jal`, `beq`, `bne`, etc.)
- Does not support system calls (`syscall`)
- Does not support memory access instructions (`lw`, `sw`, `lb`, `sb`, etc.)
- Does not handle runtime exceptions such as overflow
- No support for floating point instructions
- Labels in `.asm` files are ignored since branching is not supported

---

## Requirements

- `g++` compiler with C++17 support
- `make` build tool
- macOS / Linux / Windows (with MinGW)
