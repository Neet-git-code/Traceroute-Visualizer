#include<iostream>
#include "parser.h"
#include "registers.h"
#include "executor.h"
using namespace std;

int main(int argc,char* argv[] ){
    if(argc<2){
        cout<<"Usage: ./mips_asm <file.asm>"<<endl;
        return 0;
    }

    vector<Instruction> instructions=parseFile(argv[1]);
    RegisterFile rf;
    execute(instructions,rf);

    for(int i=0;i<32;i++){
        cout<<rf.regNames[i]<<"="<<rf.regs[i]<<endl;
    }
    cout<<"HI="<<rf.HI<<endl;
    cout<<"LO="<<rf.LO<<endl;
    return 0;
}