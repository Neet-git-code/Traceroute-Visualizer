#include "registers.h"
#include<iostream>

int RegisterFile::getReg(const std::string& name){
    if(regMap.find(name)!=regMap.end()){
        return regs[regMap[name]];
    }
    else{
        std::cout<<"Invalid Register Name"<<std::endl;
        return -1;
    }
}

void RegisterFile::setReg(const std::string& name,int value){
    if(regMap.find(name)!=regMap.end()){
        regs[regMap[name]]=value;
    }
    else{
        std::cout<<"Invalid Register Name"<<std::endl;
    }
}