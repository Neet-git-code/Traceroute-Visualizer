#pragma once
#include "registers.h"
#include "parser.h"


void execute(std::vector<Instruction>& instructions,RegisterFile& rf);