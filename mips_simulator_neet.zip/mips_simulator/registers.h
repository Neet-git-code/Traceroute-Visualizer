#pragma once
#include<string>
#include<unordered_map>
#include<cstdint>

struct RegisterFile{
    int32_t regs[32];
    int32_t HI;
    int32_t LO;
    std::unordered_map<std::string,int> regMap;

    std::string regNames[32] = {"$zero", "$at", "$v0", "$v1","$a0",   "$a1", "$a2", "$a3",
    "$t0",   "$t1", "$t2", "$t3","$t4",   "$t5", "$t6", "$t7","$s0",   "$s1", "$s2", "$s3",
    "$s4",   "$s5", "$s6", "$s7","$t8",   "$t9", "$k0", "$k1","$gp",   "$sp", "$fp", "$ra"};

    int getReg(const std::string& name);
    void setReg(const std::string& name,int value);

    RegisterFile(){
        regMap["$zero"]=0;
        regMap["$at"]=1;
        regMap["$v0"]=2;
        regMap["$v1"]=3;
        regMap["$a0"]=4;
        regMap["$a1"]=5;
        regMap["$a2"]=6;
        regMap["$a3"]=7;
        regMap["$t0"]=8;
        regMap["$t1"]=9;
        regMap["$t2"]=10;
        regMap["$t3"]=11;
        regMap["$t4"]=12;
        regMap["$t5"]=13;
        regMap["$t6"]=14;
        regMap["$t7"]=15;
        regMap["$s0"]=16;
        regMap["$s1"]=17;
        regMap["$s2"]=18;
        regMap["$s3"]=19;
        regMap["$s4"]=20;
        regMap["$s5"]=21;
        regMap["$s6"]=22;
        regMap["$s7"]=23;
        regMap["$t8"]=24;
        regMap["$t9"]=25;
        regMap["$k0"]=26;
        regMap["$k1"]=27;
        regMap["$gp"]=28;
        regMap["$sp"]=29;
        regMap["$fp"]=30;
        regMap["$ra"]=31;

        for(int i=0;i<32;i++){
            std::string temp="$";
            temp+=std::to_string(i);
            regMap[temp]=i;
        }
        for(int i=0;i<32;i++){
            regs[i]=0;
        }

        HI=0;
        LO=0;

    }
};


