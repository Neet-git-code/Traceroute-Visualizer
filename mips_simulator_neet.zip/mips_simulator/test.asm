.text
.globl main

main:
	addi $8,$0,100
	addi $9,$0,-82
	add $10,$9,$8

	addi $20,$0,2
	mult $10,$20
	mflo $22
	addi $23,$22,3
	mult $23,$23
	mflo $13