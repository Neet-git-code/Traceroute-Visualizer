#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<optional>


struct Instruction{
    std::string opcode;
    std::vector<std::string> operands;
};

std:: vector<Instruction> parseFile(std:: string filename);
std:: optional<Instruction> parseLine(std::string line);

