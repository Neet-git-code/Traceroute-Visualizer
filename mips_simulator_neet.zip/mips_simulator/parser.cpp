#include "parser.h"
#include<iostream>
#include<fstream> //file stream


std:: optional<Instruction> parseLine(std::string line){

    //this find the first non space character
    int i=0;
    while(i<line.size() && (line[i]==' ' || line[i]=='\t')){
        i++;
    }

    // we can also use this a shortcut function
    //size_t start = line.find_first_not_of(" \t");
    //if (start == std::string::npos) return std::nullopt;

    if(i==line.size()) return std::nullopt;

    line=line.substr(i); //starts the line from the i index

    if(line[0]=='#') return std::nullopt;
    if(line[0]=='.') return std::nullopt;
    

    size_t pos=line.find('#');
    if(pos!=std::string::npos){
        line=line.substr(0,pos);
    }

    i=line.size()-1;
    while(i>=0 && (line[i]==' ' || line[i]=='\t')){
        i--;
    }

    if(i<0) return std::nullopt;

    line=line.substr(0,i+1);

    std:: vector<std::string> token;

    std:: string current="";
    for(int i=0;i<line.size();i++){
        if(line[i]==',' || line[i]==' ' || line[i]=='\t'){
            if(current.size()==0) continue;
            token.push_back(current);
            current="";
        }
        else{
            current+=line[i];
        }
    }
    if(current.size()!=0) token.push_back(current);
    
    if(token.size()==0) return std::nullopt;

    Instruction inst;

    int start = 0;
    if(token[0].back() == ':') {
        start = 1;  // skip the label token
    }
    if(start >= token.size()) return std::nullopt;
    inst.opcode = token[start];
    for(int i = start+1; i < token.size(); i++) {
        inst.operands.push_back(token[i]);
    }

    return inst;
    
}

std:: vector<Instruction> parseFile(std:: string filename){
    std:: ifstream file(filename); //ifstream- input file stream 

    if(!file.is_open()){
        std:: cout<<"Error: cannot open file"<<std::endl;
        return {};
    }
    std::vector<Instruction> inst;
    std:: string line;
    while(std::getline(file,line)){
        auto result=parseLine(line);
        if(result.has_value()){
            inst.push_back(result.value());
        }
    }
    return inst;

}

